# Chart Odoo Services

## 🚀 Módulo para Gestión de Servicios Chart Odoo con IA

Módulo completo para Odoo 17 Community basado en la plataforma web Chart Odoo que permite gestionar solicitudes de demo, servicios de implementación y módulos con Inteligencia Artificial integrada.

### 📋 Características Principales

- **Gestión de Solicitudes de Demo**: Formulario web integrado con captura automática de leads
- **Inteligencia Artificial**: Puntuación automática de leads y recomendaciones inteligentes
- **Gestión de Servicios**: Catálogo completo de servicios Chart Odoo
- **Módulos Configurables**: Gestión de módulos Odoo con características de IA
- **Dashboard Analítico**: Métricas en tiempo real y reportes inteligentes
- **Integración Web**: API REST y templates personalizables

### 🤖 Funcionalidades de IA

- Puntuación automática de leads basada en criterios empresariales
- Recomendaciones inteligentes para seguimiento
- Análisis predictivo de conversión
- Priorización automática de solicitudes
- Detección de patrones en mensajes de clientes

### 🛠️ Instalación

1. Descargar el módulo en la carpeta `addons` de Odoo
2. Actualizar lista de aplicaciones
3. Instalar "Chart Odoo Services"
4. ¡Listo para usar!

### 📊 Modelos Incluidos

#### chart.demo.request
Gestión de solicitudes de demo con:
- Información de contacto completa
- Seguimiento del estado de la solicitud
- Puntuación y recomendaciones de IA
- Integración con CRM
- Notificaciones automáticas

#### chart.service
Catálogo de servicios Chart Odoo:
- Implementación con IA
- Consultoría ERP
- Desarrollo personalizado
- Soporte 24/7
- Capacitación

#### chart.module
Módulos Odoo disponibles:
- Contabilidad, Ventas, CRM
- Manufactura, Inventarios
- RRHH, Nóminas
- Reportes IA, Inventarios RF
- Y muchos más...

### 🌐 Acceso Web

- `/chart-demo` - Formulario de solicitud de demo
- `/chart-services` - Página de servicios
- `/chart-modules` - Catálogo de módulos

### 📱 API Endpoints

- `POST /chart-demo/submit` - Envío de formulario
- `POST /chart-demo/submit-ajax` - Envío AJAX
- `GET /chart-services` - Lista de servicios
- `GET /chart-modules` - Lista de módulos

### 🎯 Casos de Uso

1. **Empresas de Consultoría ERP**: Gestionar leads y solicitudes de implementación
2. **Partners Odoo**: Seguimiento de oportunidades con IA
3. **Fábricas de Software**: Catálogo de servicios y módulos
4. **Equipos de Ventas**: Dashboard con métricas de conversión

### 🌎 Específico para LATAM y España

Desarrollado para el mercado latinoamericano con:
- Idioma español nativo
- Configuraciones locales
- Cumplimiento de regulaciones regionales
- Experiencia de más de 500 implementaciones

### 📞 Soporte

Basado en Chart Odoo - Community Partner Oficial:
- **Email**: juancarlos@chart-e.com
- **Teléfono**: +52 55 3362 9528
- **Web**: chart-e.com

### 📄 Licencia

LGPL-3 - Compatible con Odoo Community

### 🔄 Versiones

- **17.0.1.0.0** - Versión inicial para Odoo 17
- Compatible con Odoo Community Edition
- Probado en Python 3.8+

---

**Desarrollado por Chart Odoo - Fábrica de Odoo con IA para LATAM y España** 🚀
