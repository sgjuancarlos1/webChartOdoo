{
    'name': 'Chart Odoo Services',
    'version': '17.0.1.0.0',
    'category': 'Services',
    'summary': 'Módulo para gestión de servicios Chart Odoo con IA integrada',
    'description': """
        Chart Odoo Services Management
        ==============================

        Este módulo proporciona funcionalidades para la gestión de servicios
        de implementación Odoo con Inteligencia Artificial integrada.

        Características principales:
        - Gestión de solicitudes de demo
        - Dashboard de servicios
        - Formulario web para captación de leads
        - Gestión de clientes potenciales
        - Reportes de conversión
        - Integración con IA para análisis

        Basado en la plataforma web Chart Odoo para Latinoamérica y España.
    """,
    'author': 'Chart Odoo',
    'website': 'https://chart-e.com',
    'depends': [
        'base',
        'mail',
        'website',
        'crm',
        'portal',
        'contacts',
    ],
    'data': [
        'security/ir.model.access.csv',
        'data/demo_data.xml',
        'data/service_data.xml',
        'views/demo_request_views.xml',
        'views/service_views.xml',
        'views/dashboard_views.xml',
        'views/website_templates.xml',
        'views/menu_views.xml',
    ],
    'assets': {
        'web.assets_backend': [
            'chart_odoo_services/static/src/css/backend.css',
            'chart_odoo_services/static/src/js/dashboard.js',
        ],
        'web.assets_frontend': [
            'chart_odoo_services/static/src/css/frontend.css',
            'chart_odoo_services/static/src/js/demo_form.js',
        ],
    },
    'demo': [
        'demo/demo_requests.xml',
    ],
    'installable': True,
    'auto_install': False,
    'application': True,
    'license': 'LGPL-3',
}
