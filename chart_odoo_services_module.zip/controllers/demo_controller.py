from odoo import http
from odoo.http import request
import json
import logging

_logger = logging.getLogger(__name__)


class DemoController(http.Controller):

    @http.route(['/chart-demo'], type='http', auth="public", website=True)
    def demo_form(self, **kwargs):
        """Página del formulario de demo"""
        return request.render('chart_odoo_services.demo_form_template', {
            'page_name': 'demo',
        })

    @http.route(['/chart-demo/submit'], type='http', auth="public", methods=['POST'], csrf=False)
    def demo_submit(self, **post):
        """Procesar envío del formulario de demo"""
        try:
            # Validar datos requeridos
            required_fields = ['name', 'email', 'company', 'company_size']
            for field in required_fields:
                if not post.get(field):
                    return self._error_response(f'El campo {field} es requerido')

            # Crear la solicitud de demo
            demo_request = request.env['chart.demo.request'].sudo().create({
                'name': post.get('name'),
                'email': post.get('email'),
                'phone': post.get('phone', ''),
                'company': post.get('company'),
                'company_size': post.get('company_size'),
                'message': post.get('message', ''),
                'source': 'website',
            })

            # Calcular puntuación IA
            demo_request.calculate_ai_score()
            demo_request.generate_ai_recommendations()

            # Log de la solicitud
            _logger.info(f'Nueva solicitud de demo creada: {demo_request.id} - {demo_request.company}')

            # Enviar notificación por email (opcional)
            self._send_notification_email(demo_request)

            return self._success_response(demo_request)

        except Exception as e:
            _logger.error(f'Error al procesar solicitud de demo: {str(e)}')
            return self._error_response('Error interno del servidor')

    @http.route(['/chart-demo/submit-ajax'], type='json', auth="public", methods=['POST'], csrf=False)
    def demo_submit_ajax(self, **kwargs):
        """Versión AJAX del envío del formulario"""
        try:
            data = request.jsonrequest

            # Validar datos requeridos
            required_fields = ['name', 'email', 'company', 'company_size']
            for field in required_fields:
                if not data.get(field):
                    return {
                        'success': False,
                        'message': f'El campo {field} es requerido'
                    }

            # Crear la solicitud de demo
            demo_request = request.env['chart.demo.request'].sudo().create({
                'name': data.get('name'),
                'email': data.get('email'),
                'phone': data.get('phone', ''),
                'company': data.get('company'),
                'company_size': data.get('company_size'),
                'message': data.get('message', ''),
                'source': 'website',
            })

            # Calcular puntuación IA
            demo_request.calculate_ai_score()
            demo_request.generate_ai_recommendations()

            # Log de la solicitud
            _logger.info(f'Nueva solicitud de demo (AJAX): {demo_request.id} - {demo_request.company}')

            # Enviar notificación por email
            self._send_notification_email(demo_request)

            return {
                'success': True,
                'message': 'Solicitud enviada correctamente. Te contactaremos pronto.',
                'request_id': demo_request.id
            }

        except Exception as e:
            _logger.error(f'Error al procesar solicitud de demo (AJAX): {str(e)}')
            return {
                'success': False,
                'message': 'Error al enviar la solicitud. Por favor, intenta de nuevo.'
            }

    def _success_response(self, demo_request):
        """Respuesta de éxito"""
        return request.render('chart_odoo_services.demo_success_template', {
            'demo_request': demo_request,
        })

    def _error_response(self, message):
        """Respuesta de error"""
        return request.render('chart_odoo_services.demo_error_template', {
            'error_message': message,
        })

    def _send_notification_email(self, demo_request):
        """Enviar email de notificación al equipo Chart Odoo"""
        try:
            # Obtener template de email
            email_template = request.env.ref('chart_odoo_services.demo_request_notification_email')
            if email_template:
                # Enviar email al equipo
                email_template.sudo().send_mail(demo_request.id, force_send=True)

                # Enviar confirmación al cliente
                confirmation_template = request.env.ref('chart_odoo_services.demo_request_confirmation_email')
                if confirmation_template:
                    confirmation_template.sudo().send_mail(demo_request.id, force_send=True)

        except Exception as e:
            _logger.error(f'Error al enviar emails de notificación: {str(e)}')

    @http.route(['/chart-services'], type='http', auth="public", website=True)
    def services_page(self, **kwargs):
        """Página de servicios Chart Odoo"""
        services = request.env['chart.service'].sudo().search([('active', '=', True)])
        modules = request.env['chart.module'].sudo().search([('active', '=', True)])

        return request.render('chart_odoo_services.services_template', {
            'services': services,
            'modules': modules,
            'page_name': 'services',
        })

    @http.route(['/chart-modules'], type='http', auth="public", website=True)
    def modules_page(self, **kwargs):
        """Página de módulos Chart Odoo"""
        modules_by_category = {}
        modules = request.env['chart.module'].sudo().search([('active', '=', True)], order='category, sequence')

        for module in modules:
            if module.category not in modules_by_category:
                modules_by_category[module.category] = []
            modules_by_category[module.category].append(module)

        return request.render('chart_odoo_services.modules_template', {
            'modules_by_category': modules_by_category,
            'page_name': 'modules',
        })
