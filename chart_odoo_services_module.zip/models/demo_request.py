from odoo import models, fields, api
from odoo.exceptions import ValidationError
import re


class DemoRequest(models.Model):
    _name = 'chart.demo.request'
    _description = 'Solicitud de Demo Chart Odoo'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'create_date desc'
    _rec_name = 'name'

    name = fields.Char(
        string='Nombre Completo',
        required=True,
        tracking=True,
        help='Nombre completo del solicitante'
    )

    email = fields.Char(
        string='Email Empresarial',
        required=True,
        tracking=True,
        help='Email empresarial del solicitante'
    )

    phone = fields.Char(
        string='Teléfono',
        tracking=True,
        help='Teléfono de contacto (opcional)'
    )

    company = fields.Char(
        string='Empresa',
        required=True,
        tracking=True,
        help='Nombre de la empresa'
    )

    company_size = fields.Selection([
        ('1-10', '1-10 empleados (Microempresa)'),
        ('11-50', '11-50 empleados (Pequeña empresa)'),
        ('51-200', '51-200 empleados (Mediana empresa)'),
        ('200+', '200+ empleados (Gran empresa)'),
    ], string='Tamaño de Empresa', required=True, tracking=True)

    message = fields.Text(
        string='Mensaje/Necesidades',
        help='Información adicional sobre el proyecto o necesidades específicas'
    )

    state = fields.Selection([
        ('new', 'Nuevo'),
        ('contacted', 'Contactado'),
        ('demo_scheduled', 'Demo Agendada'),
        ('demo_completed', 'Demo Realizada'),
        ('proposal_sent', 'Propuesta Enviada'),
        ('won', 'Ganado'),
        ('lost', 'Perdido'),
    ], string='Estado', default='new', tracking=True)

    priority = fields.Selection([
        ('0', 'Baja'),
        ('1', 'Normal'),
        ('2', 'Alta'),
        ('3', 'Urgente'),
    ], string='Prioridad', default='1')

    source = fields.Selection([
        ('website', 'Sitio Web'),
        ('email', 'Email'),
        ('phone', 'Teléfono'),
        ('referral', 'Referencia'),
        ('social', 'Redes Sociales'),
        ('other', 'Otro'),
    ], string='Fuente', default='website')

    country_id = fields.Many2one(
        'res.country',
        string='País',
        help='País de la empresa'
    )

    industry = fields.Char(
        string='Industria',
        help='Sector o industria de la empresa'
    )

    # Campos de seguimiento
    contact_date = fields.Datetime(
        string='Fecha de Contacto',
        help='Fecha en que se contactó al cliente'
    )

    demo_date = fields.Datetime(
        string='Fecha de Demo',
        help='Fecha programada para la demo'
    )

    assigned_to = fields.Many2one(
        'res.users',
        string='Asignado a',
        default=lambda self: self.env.user,
        tracking=True
    )

    # Campos relacionados con CRM
    lead_id = fields.Many2one(
        'crm.lead',
        string='Oportunidad CRM',
        help='Oportunidad creada en CRM'
    )

    partner_id = fields.Many2one(
        'res.partner',
        string='Cliente',
        help='Cliente creado a partir de esta solicitud'
    )

    # Campos de IA y análisis
    ai_score = fields.Float(
        string='Puntuación IA',
        help='Puntuación calculada por IA para priorización',
        default=0.0
    )

    ai_recommendation = fields.Text(
        string='Recomendación IA',
        help='Recomendaciones generadas por IA'
    )

    # Campos calculados
    days_since_request = fields.Integer(
        string='Días desde solicitud',
        compute='_compute_days_since_request',
        store=True
    )

    @api.depends('create_date')
    def _compute_days_since_request(self):
        for record in self:
            if record.create_date:
                delta = fields.Datetime.now() - record.create_date
                record.days_since_request = delta.days
            else:
                record.days_since_request = 0

    @api.constrains('email')
    def _check_email_format(self):
        for record in self:
            if record.email:
                email_pattern = r'^[^\s@]+@[^\s@]+\.[^\s@]+$'
                if not re.match(email_pattern, record.email):
                    raise ValidationError('Por favor ingresa un email válido.')

    @api.constrains('phone')
    def _check_phone_format(self):
        for record in self:
            if record.phone:
                # Remover espacios, guiones y paréntesis
                clean_phone = re.sub(r'[\s\-\(\)]', '', record.phone)
                phone_pattern = r'^[\+]?[1-9][\d]{0,15}$'
                if not re.match(phone_pattern, clean_phone):
                    raise ValidationError('Por favor ingresa un teléfono válido.')

    def action_contact_client(self):
        """Marcar como contactado y actualizar fecha"""
        self.write({
            'state': 'contacted',
            'contact_date': fields.Datetime.now()
        })
        self.message_post(body=f"Cliente contactado por {self.env.user.name}")

    def action_schedule_demo(self):
        """Programar demo"""
        self.write({'state': 'demo_scheduled'})
        # Aquí se podría integrar con calendario
        return {
            'type': 'ir.actions.act_window',
            'name': 'Programar Demo',
            'res_model': 'chart.demo.request',
            'res_id': self.id,
            'view_mode': 'form',
            'target': 'current',
        }

    def action_create_crm_lead(self):
        """Crear oportunidad en CRM"""
        if not self.lead_id:
            lead_vals = {
                'name': f'Demo {self.company} - {self.name}',
                'contact_name': self.name,
                'email_from': self.email,
                'phone': self.phone,
                'partner_name': self.company,
                'description': self.message,
                'user_id': self.assigned_to.id,
                'team_id': self.env.ref('sales_team.team_sales_department', raise_if_not_found=False).id,
                'stage_id': self.env.ref('crm.stage_lead1', raise_if_not_found=False).id,
            }

            lead = self.env['crm.lead'].create(lead_vals)
            self.lead_id = lead.id
            self.message_post(
                body=f"Oportunidad CRM creada: <a href='#' data-oe-model='crm.lead' data-oe-id='{lead.id}'>{lead.name}</a>"
            )

        return {
            'type': 'ir.actions.act_window',
            'name': 'Oportunidad CRM',
            'res_model': 'crm.lead',
            'res_id': self.lead_id.id,
            'view_mode': 'form',
            'target': 'current',
        }

    def action_create_partner(self):
        """Crear cliente a partir de la solicitud"""
        if not self.partner_id:
            partner_vals = {
                'name': self.company,
                'email': self.email,
                'phone': self.phone,
                'is_company': True,
                'customer_rank': 1,
                'country_id': self.country_id.id if self.country_id else False,
                'comment': f'Cliente creado desde solicitud de demo de {self.name}',
            }

            partner = self.env['res.partner'].create(partner_vals)
            self.partner_id = partner.id
            self.message_post(
                body=f"Cliente creado: <a href='#' data-oe-model='res.partner' data-oe-id='{partner.id}'>{partner.name}</a>"
            )

        return {
            'type': 'ir.actions.act_window',
            'name': 'Cliente',
            'res_model': 'res.partner',
            'res_id': self.partner_id.id,
            'view_mode': 'form',
            'target': 'current',
        }

    @api.model
    def calculate_ai_score(self):
        """Calcular puntuación IA basada en criterios"""
        for record in self:
            score = 50.0  # Base score

            # Puntuación por tamaño de empresa
            size_scores = {
                '1-10': 60,
                '11-50': 75,
                '51-200': 85,
                '200+': 95,
            }
            score += size_scores.get(record.company_size, 0) * 0.3

            # Puntuación por mensaje detallado
            if record.message and len(record.message) > 50:
                score += 15

            # Puntuación por teléfono proporcionado
            if record.phone:
                score += 10

            # Penalización por días sin contacto
            if record.days_since_request > 2:
                score -= record.days_since_request * 2

            record.ai_score = min(100, max(0, score))

    @api.model
    def generate_ai_recommendations(self):
        """Generar recomendaciones IA"""
        for record in self:
            recommendations = []

            if record.state == 'new' and record.days_since_request > 1:
                recommendations.append("🔴 URGENTE: Contactar cliente en las próximas 2 horas")

            if record.company_size in ['51-200', '200+']:
                recommendations.append("🎯 Cliente empresarial - Asignar consultor senior")

            if record.message and 'manufactura' in record.message.lower():
                recommendations.append("🏭 Necesidades de manufactura - Mostrar módulo MRP")

            if record.message and 'contabilidad' in record.message.lower():
                recommendations.append("📊 Enfoque en módulos financieros y contables")

            if not record.phone:
                recommendations.append("📞 Solicitar teléfono de contacto para mejor seguimiento")

            record.ai_recommendation = '\n'.join(recommendations) if recommendations else "✅ Seguimiento estándar"
