from odoo import models, fields, api


class ChartService(models.Model):
    _name = 'chart.service'
    _description = 'Servicios Chart Odoo'
    _order = 'sequence, name'

    name = fields.Char(
        string='Nombre del Servicio',
        required=True,
        help='Nombre del servicio ofrecido'
    )

    description = fields.Text(
        string='Descripción',
        help='Descripción detallada del servicio'
    )

    category = fields.Selection([
        ('implementation', 'Implementación'),
        ('consulting', 'Consultoría'),
        ('development', 'Desarrollo'),
        ('support', 'Soporte'),
        ('training', 'Capacitación'),
        ('ai_integration', 'Integración IA'),
    ], string='Categoría', required=True)

    sequence = fields.Integer(
        string='Secuencia',
        default=10,
        help='Orden de visualización'
    )

    active = fields.Boolean(
        string='Activo',
        default=True
    )

    icon = fields.Char(
        string='Ícono',
        help='Ícono representativo del servicio (emoji o clase CSS)'
    )

    color = fields.Char(
        string='Color',
        help='Color hexadecimal para la visualización'
    )

    # Campos de pricing
    price_type = fields.Selection([
        ('fixed', 'Precio Fijo'),
        ('hourly', 'Por Hora'),
        ('monthly', 'Mensual'),
        ('custom', 'Personalizado'),
    ], string='Tipo de Precio', default='custom')

    price = fields.Float(
        string='Precio Base',
        help='Precio base del servicio'
    )

    currency_id = fields.Many2one(
        'res.currency',
        string='Moneda',
        default=lambda self: self.env.company.currency_id
    )

    # Campos relacionados con módulos Odoo
    odoo_modules = fields.Text(
        string='Módulos Odoo Relacionados',
        help='Lista de módulos de Odoo relacionados con este servicio'
    )

    # Campos de IA
    ai_enhanced = fields.Boolean(
        string='Potenciado por IA',
        default=False,
        help='Servicio incluye funcionalidades de IA'
    )

    ai_features = fields.Text(
        string='Características IA',
        help='Descripción de las características de IA incluidas'
    )

    # Campos de seguimiento
    request_count = fields.Integer(
        string='Solicitudes',
        compute='_compute_request_count',
        help='Número de solicitudes para este servicio'
    )

    @api.depends('name')
    def _compute_request_count(self):
        for service in self:
            # Aquí se podría contar las solicitudes relacionadas
            service.request_count = 0


class ChartModule(models.Model):
    _name = 'chart.module'
    _description = 'Módulos Chart Odoo'
    _order = 'category, sequence, name'

    name = fields.Char(
        string='Nombre del Módulo',
        required=True,
        help='Nombre del módulo'
    )

    technical_name = fields.Char(
        string='Nombre Técnico',
        help='Nombre técnico del módulo en Odoo'
    )

    description = fields.Text(
        string='Descripción',
        help='Descripción del módulo'
    )

    category = fields.Selection([
        ('accounting', 'Contabilidad'),
        ('sales', 'Ventas'),
        ('crm', 'CRM'),
        ('purchase', 'Compras'),
        ('inventory', 'Almacén'),
        ('manufacturing', 'Manufactura'),
        ('hr', 'RRHH'),
        ('payroll', 'Nóminas'),
        ('invoicing', 'Facturación'),
        ('rfid', 'Inventarios RF'),
        ('ai_reports', 'Reportes IA'),
        ('services', 'Servicios'),
        ('other', 'Otros'),
    ], string='Categoría', required=True)

    icon = fields.Char(
        string='Ícono',
        help='Ícono del módulo (emoji)'
    )

    color_class = fields.Char(
        string='Clase de Color',
        help='Clase CSS para el color de fondo'
    )

    sequence = fields.Integer(
        string='Secuencia',
        default=10
    )

    active = fields.Boolean(
        string='Activo',
        default=True
    )

    # Campos de implementación
    implementation_time = fields.Float(
        string='Tiempo de Implementación (días)',
        help='Tiempo estimado de implementación en días'
    )

    complexity = fields.Selection([
        ('basic', 'Básico'),
        ('intermediate', 'Intermedio'),
        ('advanced', 'Avanzado'),
        ('expert', 'Experto'),
    ], string='Complejidad', default='basic')

    # Campos de IA
    ai_features = fields.Boolean(
        string='Incluye IA',
        default=False,
        help='El módulo incluye características de IA'
    )

    ai_description = fields.Text(
        string='Descripción IA',
        help='Descripción de las características de IA'
    )

    # Relaciones
    service_ids = fields.Many2many(
        'chart.service',
        string='Servicios Relacionados',
        help='Servicios que incluyen este módulo'
    )
