/** @odoo-module **/

import { registry } from "@web/core/registry";
import { Component, useState, onWillStart } from "@odoo/owl";
import { useService } from "@web/core/utils/hooks";

class ChartOdooDashboard extends Component {
    setup() {
        this.orm = useService("orm");
        this.state = useState({
            stats: {
                total_requests: 0,
                new_requests: 0,
                in_progress: 0,
                completed: 0,
                cancelled: 0
            },
            recent_requests: [],
            loading: true
        });

        onWillStart(async () => {
            await this.loadDashboardData();
        });
    }

    async loadDashboardData() {
        try {
            // Load statistics
            const stats = await this.orm.call(
                "demo.request",
                "get_dashboard_stats",
                []
            );

            // Load recent requests
            const recent_requests = await this.orm.searchRead(
                "demo.request",
                [],
                ["name", "email", "company", "state", "create_date", "service_id"],
                {
                    limit: 10,
                    order: "create_date desc"
                }
            );

            this.state.stats = stats;
            this.state.recent_requests = recent_requests;
            this.state.loading = false;
        } catch (error) {
            console.error("Error loading dashboard data:", error);
            this.state.loading = false;
        }
    }

    async refreshData() {
        this.state.loading = true;
        await this.loadDashboardData();
    }

    formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('es-ES', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
    }

    getStateLabel(state) {
        const labels = {
            'new': 'Nuevo',
            'in_progress': 'En Progreso',
            'completed': 'Completado',
            'cancelled': 'Cancelado'
        };
        return labels[state] || state;
    }

    getStateClass(state) {
        return `status_badge status_${state}`;
    }
}

ChartOdooDashboard.template = "chart_odoo_services.DashboardTemplate";

// Register the component
registry.category("actions").add("chart_odoo_dashboard", ChartOdooDashboard);

// Dashboard utility functions
window.ChartOdooUtils = {
    // Format numbers with Spanish locale
    formatNumber: (num) => {
        return new Intl.NumberFormat('es-ES').format(num);
    },

    // Format currency
    formatCurrency: (amount) => {
        return new Intl.NumberFormat('es-ES', {
            style: 'currency',
            currency: 'EUR'
        }).format(amount);
    },

    // Show notification
    showNotification: (message, type = 'success') => {
        const notification = document.createElement('div');
        notification.className = `alert alert-${type} alert-dismissible fade show`;
        notification.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;

        const container = document.querySelector('.o_content') || document.body;
        container.insertBefore(notification, container.firstChild);

        setTimeout(() => {
            notification.remove();
        }, 5000);
    },

    // Validate email
    validateEmail: (email) => {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    },

    // Validate phone
    validatePhone: (phone) => {
        const phoneRegex = /^\+?[\d\s\-\(\)]{9,}$/;
        return phoneRegex.test(phone);
    }
};

// Auto-refresh dashboard every 5 minutes
setInterval(() => {
    if (window.location.pathname.includes('chart_odoo')) {
        const dashboard = document.querySelector('.chart_odoo_dashboard');
        if (dashboard) {
            console.log('Auto-refreshing Chart Odoo dashboard...');
            // Trigger refresh if component is available
            const refreshBtn = dashboard.querySelector('.refresh_btn');
            if (refreshBtn) {
                refreshBtn.click();
            }
        }
    }
}, 300000); // 5 minutes
