// Chart Odoo Services - Demo Form JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Initialize demo form functionality
    initDemoForm();
    initAnimations();
    initValidation();
});

function initDemoForm() {
    const demoForm = document.getElementById('demo_request_form');
    if (!demoForm) return;

    demoForm.addEventListener('submit', async function(e) {
        e.preventDefault();

        if (!validateForm()) {
            return false;
        }

        await submitDemoForm();
    });

    // Auto-format phone number
    const phoneInput = document.getElementById('phone');
    if (phoneInput) {
        phoneInput.addEventListener('input', function() {
            this.value = formatPhoneNumber(this.value);
        });
    }

    // Employee count suggestions
    const employeesInput = document.getElementById('employees');
    if (employeesInput) {
        employeesInput.addEventListener('change', function() {
            showServiceSuggestions(parseInt(this.value));
        });
    }
}

function initAnimations() {
    // Animate elements when they come into view
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('fade-in-up');
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);

    // Observe service items and form sections
    document.querySelectorAll('.service_item, .demo_form_container').forEach(el => {
        observer.observe(el);
    });
}

function initValidation() {
    const inputs = document.querySelectorAll('.form-control');

    inputs.forEach(input => {
        input.addEventListener('blur', function() {
            validateField(this);
        });

        input.addEventListener('input', function() {
            clearFieldError(this);
        });
    });
}

function validateForm() {
    let isValid = true;
    const requiredFields = ['name', 'email', 'phone', 'company', 'employees'];

    requiredFields.forEach(fieldName => {
        const field = document.getElementById(fieldName);
        if (!validateField(field)) {
            isValid = false;
        }
    });

    return isValid;
}

function validateField(field) {
    const value = field.value.trim();
    let isValid = true;
    let errorMessage = '';

    // Check if required field is empty
    if (field.hasAttribute('required') && !value) {
        errorMessage = 'Este campo es obligatorio';
        isValid = false;
    }
    // Validate email
    else if (field.type === 'email' && value && !ChartOdooUtils.validateEmail(value)) {
        errorMessage = 'Por favor ingresa un email válido';
        isValid = false;
    }
    // Validate phone
    else if (field.id === 'phone' && value && !ChartOdooUtils.validatePhone(value)) {
        errorMessage = 'Por favor ingresa un teléfono válido';
        isValid = false;
    }
    // Validate employees (must be positive number)
    else if (field.id === 'employees' && value && (isNaN(value) || parseInt(value) <= 0)) {
        errorMessage = 'Debe ser un número mayor a 0';
        isValid = false;
    }

    if (!isValid) {
        showFieldError(field, errorMessage);
    } else {
        clearFieldError(field);
    }

    return isValid;
}

function showFieldError(field, message) {
    clearFieldError(field);

    field.classList.add('is-invalid');

    const errorDiv = document.createElement('div');
    errorDiv.className = 'invalid-feedback';
    errorDiv.textContent = message;

    field.parentNode.appendChild(errorDiv);
}

function clearFieldError(field) {
    field.classList.remove('is-invalid');

    const errorDiv = field.parentNode.querySelector('.invalid-feedback');
    if (errorDiv) {
        errorDiv.remove();
    }
}

async function submitDemoForm() {
    const form = document.getElementById('demo_request_form');
    const submitBtn = form.querySelector('button[type="submit"]');
    const originalText = submitBtn.textContent;

    try {
        // Show loading state
        submitBtn.textContent = 'Enviando...';
        submitBtn.disabled = true;
        form.classList.add('loading');

        // Prepare form data
        const formData = new FormData(form);
        const data = Object.fromEntries(formData.entries());

        // Submit via AJAX
        const response = await fetch('/demo/request/submit', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: JSON.stringify(data)
        });

        const result = await response.json();

        if (response.ok && result.success) {
            showSuccessMessage();
            form.reset();

            // Optional: redirect after success
            setTimeout(() => {
                window.location.href = '/demo/thank-you';
            }, 2000);
        } else {
            throw new Error(result.message || 'Error al enviar el formulario');
        }

    } catch (error) {
        console.error('Error submitting form:', error);
        showErrorMessage(error.message);
    } finally {
        // Reset button state
        submitBtn.textContent = originalText;
        submitBtn.disabled = false;
        form.classList.remove('loading');
    }
}

function showSuccessMessage() {
    const message = `
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-2"></i>
            ¡Gracias! Tu solicitud ha sido enviada correctamente.
            Nos pondremos en contacto contigo pronto.
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `;

    showNotification(message);
}

function showErrorMessage(errorMsg) {
    const message = `
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-triangle me-2"></i>
            Error al enviar la solicitud: ${errorMsg}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `;

    showNotification(message);
}

function showNotification(html) {
    const container = document.querySelector('.demo_form_container') || document.body;
    const notification = document.createElement('div');
    notification.innerHTML = html;

    container.insertBefore(notification.firstElementChild, container.firstChild);
}

function formatPhoneNumber(phone) {
    // Remove all non-numeric characters except +
    let cleaned = phone.replace(/[^\d+]/g, '');

    // Format Spanish phone numbers
    if (cleaned.startsWith('+34')) {
        cleaned = cleaned.replace(/(\+34)(\d{3})(\d{3})(\d{3})/, '$1 $2 $3 $4');
    }
    // Format Mexican phone numbers
    else if (cleaned.startsWith('+52')) {
        cleaned = cleaned.replace(/(\+52)(\d{3})(\d{3})(\d{4})/, '$1 $2 $3 $4');
    }

    return cleaned;
}

function showServiceSuggestions(employeeCount) {
    let suggestions = [];

    if (employeeCount <= 10) {
        suggestions = ['Odoo Community', 'Implementación Básica', 'Capacitación Inicial'];
    } else if (employeeCount <= 50) {
        suggestions = ['Odoo Enterprise', 'Implementación Completa', 'Capacitación Avanzada'];
    } else {
        suggestions = ['Odoo Enterprise Premium', 'Implementación Corporativa', 'Soporte 24/7'];
    }

    // Show suggestions (implement based on your UI needs)
    console.log('Suggestions for', employeeCount, 'employees:', suggestions);
}

// Smooth scrolling for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Add Chart Odoo Utils if not already defined
if (typeof ChartOdooUtils === 'undefined') {
    window.ChartOdooUtils = {
        validateEmail: (email) => {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return emailRegex.test(email);
        },

        validatePhone: (phone) => {
            const phoneRegex = /^\+?[\d\s\-\(\)]{9,}$/;
            return phoneRegex.test(phone);
        }
    };
}
